package config

type Config struct {
}
