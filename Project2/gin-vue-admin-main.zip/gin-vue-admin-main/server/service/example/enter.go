package example

type ServiceGroup struct {
	CustomerService
	FileUploadAndDownloadService
}
