package dao

//
// func TestTasks_Create(t *testing.T) {
//	InitDB()
//	f := new(Task)
//	req := new(user.TaskRequest)
//	req.UserID=4
//	req.UserID=4
//	req.UserID=4
//	err := f.Create(req)
//	fmt.Println(err)
// }
//
// func TestTasks_Show(t *testing.T) {
//	InitDB()
//	f := new(Task)
//	req := new(user.TaskRequest)
//	req.UserID=1
//	res,err := f.Show(req)
//	if err != nil {
//		fmt.Println(err)
//	}
//	fmt.Println(res)
// }
//
// func TestTasks_Update(t *testing.T) {
//	InitDB()
//	f := new(Task)
//	req := new(user.TaskRequest)
//	req.TaskID=1
//	req.Title="knowledge again"
//	err := f.Update(req)
//	fmt.Println(err)
// }
//
// func TestTasks_Delete(t *testing.T) {
//	InitDB()
//	f := new(Task)
//	req := new(user.TaskRequest)
//	req.TaskID = 1
//	err := f.Delete(req)
//	fmt.Println(err)
// }
