package consts

const (
	PassWordCost = 12 // 密码加密难度
)

const UserIdKey = "UserIdKey"
